package com.ibatis.sqlmap.engine.mapper;

public class ClassMapper {

  

}
