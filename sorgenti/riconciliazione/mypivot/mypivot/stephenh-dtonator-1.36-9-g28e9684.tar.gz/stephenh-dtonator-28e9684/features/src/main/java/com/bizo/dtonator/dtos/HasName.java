package com.bizo.dtonator.dtos;

public interface HasName {

  String getName();

}
