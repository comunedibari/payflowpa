package com.bizo.dtonator.config;

public enum Prune {

  DISABLED, ALL_PACKAGES, USED_PACKAGES;

}
